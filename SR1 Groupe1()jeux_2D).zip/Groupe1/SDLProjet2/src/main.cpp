/*Pour compiler taper la lgne de commande ci dessous
 g++ -std=c++17  src/main.cpp -o prog -I include -L lib -lmingw32 -lSDL2main -lSDL2 
*/

#include<SDL.h>
//#include<SDL_ttf.h>
#include<iostream>
#include<cstdlib>
#define WINDOW_HEIGHT 600
#define WINDOW_WIDTH 800
#define Vitess 5

typedef struct joueur{
SDL_Rect rectangle;
int vitesseX;
}joueur;

typedef struct objet{
SDL_Rect rectangle;
int vitesseY;
}objet;

int main(int argc, char **argv){
    SDL_Window *window = NULL;
    SDL_Renderer *renderer = NULL;
//intialisation du temps

Uint32 temps_debut = SDL_GetTicks();
Uint32 temps_ecoule = 0;
float vitesse = 1.0f; 

    //initialisation de la sdl
    if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO)!=0){
SDL_Log("Impossible d'initialiser la sdl %s", SDL_GetError());
SDL_Quit();
exit(EXIT_FAILURE);
}

//creation de la fenetre

window = SDL_CreateWindow("jeux 2D", SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,  WINDOW_WIDTH , WINDOW_HEIGHT, 0);

if(window == NULL){
    SDL_Log("Impossible de cree la fenetre %s", SDL_GetError());
SDL_Quit();
exit(EXIT_FAILURE);
}

//creation du rendu

renderer=SDL_CreateRenderer(window, -1, SDL_RENDERER_SOFTWARE);

if(renderer == NULL){
    SDL_Log("Impossible de creer le rendu %s", SDL_GetError());
SDL_Quit();
exit(EXIT_FAILURE);
}

//creation du joueur

joueur joueur;
joueur.rectangle.x = 100;
joueur.rectangle.y = WINDOW_HEIGHT - 90;
joueur.rectangle.w = 50;
joueur.rectangle.h = 50;
joueur.vitesseX = Vitess;

//creation des objets

objet objet1;
objet1.rectangle.x = 150;
objet1.rectangle.y = 0;
objet1.rectangle.w = 50;
objet1.rectangle.h = 50;
objet1.vitesseY=Vitess;
objet objet2;
objet2.rectangle.x = 385;
objet2.rectangle.y= 0;
objet2.rectangle.w = 50;
objet2.rectangle.h = 50;
objet2.vitesseY=Vitess;
objet objet3;
objet3.rectangle.x = 600;
objet3.rectangle.y = 0;
objet3.rectangle.w = 50;
objet3.rectangle.h = 50;
objet3.vitesseY=Vitess;


SDL_bool program_launched = SDL_TRUE;
while(program_launched){
      SDL_Event event;
        while(SDL_PollEvent(&event)){
        switch(event.type)
            {
                case SDL_QUIT:
                    program_launched = SDL_FALSE;
                        break;
                default:
                        continue;
            }
        }

        // calcule du temps
            temps_ecoule = (SDL_GetTicks() - temps_debut) / 1000;
            //augmentation de la vitesse
            if(temps_ecoule % 45 == 0 && temps_ecoule != 0) {
                vitesse += 0.025f;
            }

        //deplacement du joueur et objet

const Uint8* keystates = SDL_GetKeyboardState(NULL);
if(keystates[SDL_SCANCODE_LEFT]){
    joueur.rectangle.x -= joueur.vitesseX;
    if(joueur.rectangle.x < 0){
        joueur.rectangle.x = 0;
    }
}

if(keystates[SDL_SCANCODE_RIGHT]){
    joueur.rectangle.x += joueur.vitesseX;
    if(joueur.rectangle.x + joueur.rectangle.w >  WINDOW_WIDTH){
        joueur.rectangle.x =  WINDOW_WIDTH - joueur.rectangle.w;
    }
}
 //RENDU

SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
SDL_RenderClear(renderer);

SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
SDL_RenderFillRect(renderer, &joueur.rectangle);

 SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
 SDL_RenderFillRect(renderer, &objet1.rectangle);
  SDL_RenderFillRect(renderer, &objet2.rectangle);
  SDL_RenderFillRect(renderer, &objet3.rectangle);

  //gestion de collision

SDL_Rect collision;

objet1.rectangle.y = objet1.rectangle.y + objet1.vitesseY;
if(objet1.rectangle.y > WINDOW_HEIGHT){
   objet1.rectangle.y= 0;
   //objet1.rectangle.x = rand() % (WINDOW_WIDTH - objet1.rectangle.w);
}
if(SDL_IntersectRect(&objet1.rectangle, &joueur.rectangle, &collision)){
     std::cout<<"FIN";
}

objet2.rectangle.y = objet2.rectangle.y + objet2.vitesseY;
if(objet2.rectangle.y > WINDOW_HEIGHT){
    objet2.rectangle.y = 0;
    //objet2.rectangle.x = rand() % (WINDOW_WIDTH - objet2.rectangle.w);
}
if(SDL_IntersectRect(&objet2.rectangle, &joueur.rectangle, &collision)){
     std::cout<<"FIN";
}

objet3.rectangle.y = objet3.rectangle.y + objet3.vitesseY;
if(objet3.rectangle.y > WINDOW_HEIGHT){
    objet3.rectangle.y= 0;
   // objet3.rectangle.x = rand() % (WINDOW_WIDTH - objet3.rectangle.w);
}
if(SDL_IntersectRect(&objet3.rectangle, &joueur.rectangle, &collision)){
     std::cout<<"FIN";
}

  
SDL_RenderPresent(renderer);
//delai pour limiter la vitesse de la boucle
SDL_Delay(1000 / (60*vitesse));
}

SDL_DestroyRenderer(renderer);
SDL_DestroyWindow(window);
SDL_Quit();
    return 0;
    }